# Deploying NLPTrader to a free public URL

Goal: a working dashboard your teacher can open from a link. Host = **Streamlit Community
Cloud** (free). The hosted app is **display-only** — it shows your data snapshot
(`nlptrader.db`) and doesn't run FinBERT on the server, so it stays fast and free.

Time: ~5–10 minutes. You'll need a free **GitHub** account.

---

## Before you start
Make sure these files are in your `nlptrader` folder (they should be):
`app.py, db.py, config.py, ingest.py, sentiment.py, signal_engine.py, llm_explain.py,
relevance.py, clean_relevance.py, requirements.txt, .gitignore, nlptrader.db`

Optional polish: create a file `.streamlit/config.toml` so the glass theme stays dark:
```
[theme]
base = "dark"
primaryColor = "#5b8def"
```

---

## Step 1 — Put the project on GitHub
1. Create a free account at https://github.com
2. Click **New repository** → name it `nlptrader` → keep it **Public** → Create.
3. Easiest upload (no commands): on the repo page click **uploading an existing file**,
   then drag in ALL the files listed above (including `nlptrader.db`). Commit.

   - Do NOT upload `.env` or the `venv` folder. (`.gitignore` already excludes them, but
     if you drag-and-drop, just skip them manually.)

## Step 2 — Deploy on Streamlit Cloud
1. Go to https://share.streamlit.io and sign in **with GitHub**.
2. Click **Create app** → **Deploy a public app from GitHub**.
3. Pick your `nlptrader` repo, branch `main`, main file `app.py`.
4. Click **Deploy**. First build takes 1–3 minutes.

## Step 3 — Share
You'll get a URL like `https://nlptrader-yourname.streamlit.app`. Send it to your teacher.
It works from any device, no install.

---

## Notes / honest limits
- The **Refresh button is hidden** on the hosted app (no torch on the server). The data is a
  snapshot — to update it, re-run the pipeline locally, commit the new `nlptrader.db`, and
  Streamlit auto-redeploys.
- Free apps **sleep after inactivity**; the first visit may take ~30s to wake. Open the link
  yourself once before your teacher does.
- No API keys are needed on the server for the display-only app, so nothing secret is exposed.
